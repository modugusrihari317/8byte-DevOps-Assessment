variable "project_name"        { type = string }
variable "environment"          { type = string }
variable "vpc_id"               { type = string }
variable "private_subnet_ids"   { type = list(string) }
variable "rds_sg_id"            { type = string }
variable "db_name"              { type = string }
variable "db_username"          { type = string }
variable "db_instance_class"    { type = string }
variable "db_allocated_storage" { type = number }
variable "multi_az"             { type = bool;   default = false }
variable "backup_retention"     { type = number; default = 7 }
