variable "project_name"       { type = string }
variable "environment"         { type = string }
variable "ami_id"              { type = string }
variable "instance_type"       { type = string }
variable "private_subnet_ids"  { type = list(string) }
variable "app_sg_id"           { type = string }
variable "key_name"            { type = string; default = "" }
variable "target_group_arn"    { type = string }
variable "min_size"            { type = number }
variable "max_size"            { type = number }
variable "desired_capacity"    { type = number }
variable "db_endpoint"         { type = string }
variable "db_name"             { type = string }
variable "db_username"         { type = string }
variable "db_secret_arn"       { type = string }
