#!/bin/bash
set -euo pipefail

# ─── System Setup ───────────────────────────────────────
yum update -y
yum install -y docker aws-cli jq

# ─── Start Docker ───────────────────────────────────────
systemctl enable docker
systemctl start docker
usermod -aG docker ec2-user

# ─── Fetch DB credentials from Secrets Manager ─────────
SECRET=$(aws secretsmanager get-secret-value \
  --secret-id "${db_secret_arn}" \
  --region ap-south-1 \
  --query SecretString \
  --output text)

DB_PASSWORD=$(echo $SECRET | jq -r '.password')

# ─── Write app environment file ─────────────────────────
cat > /etc/app.env <<EOF
NODE_ENV=${environment}
DB_HOST=${db_endpoint}
DB_PORT=5432
DB_NAME=${db_name}
DB_USER=${db_username}
DB_PASSWORD=$DB_PASSWORD
PORT=3000
EOF

# ─── Pull & run application container ──────────────────
# Image pulled from ECR — injected at deploy time by CI/CD
# docker pull $ECR_IMAGE
# docker run -d --restart always --env-file /etc/app.env -p 3000:3000 $ECR_IMAGE

# ─── Install Node Exporter (Prometheus metrics) ─────────
useradd -rs /bin/false node_exporter || true
NODE_EXPORTER_VERSION="1.7.0"
cd /tmp
curl -sSfL "https://github.com/prometheus/node_exporter/releases/download/v$${NODE_EXPORTER_VERSION}/node_exporter-$${NODE_EXPORTER_VERSION}.linux-amd64.tar.gz" \
  | tar xvz
cp node_exporter-*/node_exporter /usr/local/bin/
chown node_exporter:node_exporter /usr/local/bin/node_exporter

cat > /etc/systemd/system/node_exporter.service <<UNIT
[Unit]
Description=Node Exporter
After=network.target

[Service]
User=node_exporter
ExecStart=/usr/local/bin/node_exporter
Restart=on-failure

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable node_exporter
systemctl start node_exporter

echo "Bootstrap complete!"
