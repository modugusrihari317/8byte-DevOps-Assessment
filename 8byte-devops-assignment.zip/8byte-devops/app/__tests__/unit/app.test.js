const request = require('supertest');
const app = require('../index');

// Mock pg pool so tests don't need a real DB
jest.mock('pg', () => {
  const mPool = {
    query: jest.fn(),
    end: jest.fn(),
  };
  return { Pool: jest.fn(() => mPool) };
});

const { Pool } = require('pg');
const pool = new Pool();

describe('GET /health', () => {
  it('returns 200 when DB is connected', async () => {
    pool.query.mockResolvedValueOnce({ rows: [{ '?column?': 1 }] });
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.db).toBe('connected');
  });

  it('returns 503 when DB is down', async () => {
    pool.query.mockRejectedValueOnce(new Error('Connection refused'));
    const res = await request(app).get('/health');
    expect(res.statusCode).toBe(503);
    expect(res.body.status).toBe('error');
  });
});

describe('GET /api/users', () => {
  it('returns list of users', async () => {
    pool.query.mockResolvedValueOnce({
      rows: [{ id: 1, name: 'Alice', email: 'alice@test.com', created_at: new Date() }],
      rowCount: 1,
    });
    const res = await request(app).get('/api/users');
    expect(res.statusCode).toBe(200);
    expect(res.body.users).toHaveLength(1);
    expect(res.body.count).toBe(1);
  });
});

describe('POST /api/users', () => {
  it('creates a user and returns 201', async () => {
    const newUser = { id: 2, name: 'Bob', email: 'bob@test.com', created_at: new Date() };
    pool.query.mockResolvedValueOnce({ rows: [newUser] });
    const res = await request(app)
      .post('/api/users')
      .send({ name: 'Bob', email: 'bob@test.com' });
    expect(res.statusCode).toBe(201);
    expect(res.body.name).toBe('Bob');
  });

  it('returns 400 when name or email is missing', async () => {
    const res = await request(app).post('/api/users').send({ name: 'Incomplete' });
    expect(res.statusCode).toBe(400);
  });
});

describe('GET /metrics', () => {
  it('returns Prometheus metrics', async () => {
    const res = await request(app).get('/metrics');
    expect(res.statusCode).toBe(200);
    expect(res.text).toContain('http_requests_total');
  });
});
